<?php 
define("MDAPPTYPE","app");
if(!defined("OPEN_UPLOAD_VIDEO")){
	define("OPEN_UPLOAD_VIDEO",true);
}

?>