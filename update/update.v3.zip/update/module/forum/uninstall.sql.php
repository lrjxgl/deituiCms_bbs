<?php
$content=<<<eof
drop table sky_mod_forum ;
drop table sky_mod_forum_category ;
drop table sky_mod_forum_comment ;
drop table sky_mod_forum_config ;
drop table sky_mod_forum_data ;
drop table sky_mod_forum_feeds ;
drop table sky_mod_forum_group ;
drop table sky_mod_forum_group_admin ;
drop table sky_mod_forum_img ;
drop table sky_mod_forum_tags ;
drop table sky_mod_forum_tags_index ;

eof;
?>