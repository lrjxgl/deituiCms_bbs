# 得推论坛系统
得推论坛系统是基于deituiCMS开发的轻论坛，支持金币打赏，支持公众号、小程序、App 
uniApp客户端 https://github.com/lrjxgl/uniBBS 
开源协议：https://www.deituicms.com/index.php?m=article&a=show&id=25 
